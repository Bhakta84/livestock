# BLDCL E-Procurement — Deployment Guide

## 1. Frontend (Vercel)

Import this GitHub repository into Vercel. Set:

- Framework Preset: Vite
- Root Directory: `frontend`
- Build Command: `npm run build`
- Output Directory: `dist`

Add Vercel Environment Variable:

`VITE_API_BASE_URL=https://YOUR-BACKEND-DOMAIN/api`

Redeploy after saving the variable.

## 2. Backend (Django)

Deploy the `backend` directory to a Python host (for example Render, Railway, or a VPS). Use Python 3.12 or a compatible version. Install:

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic --noinput
python manage.py createsuperuser
```

Start with:

```bash
gunicorn config.wsgi:application
```

Set environment variables using `backend/.env.example`. Use PostgreSQL for production via `DATABASE_URL`.

## 3. Connect frontend and backend

After the backend has a public HTTPS URL, set on Vercel:

```text
VITE_API_BASE_URL=https://YOUR-BACKEND-DOMAIN/api
```

On the backend set:

```text
ALLOWED_HOSTS=YOUR-BACKEND-DOMAIN
CORS_ALLOWED_ORIGINS=https://YOUR-VERCEL-DOMAIN
CSRF_TRUSTED_ORIGINS=https://YOUR-VERCEL-DOMAIN
DEBUG=0
SECURE_SSL=1
```

## 4. Local development

Frontend:

```bash
cd frontend
npm install
npm run dev
```

Backend:

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

The local frontend uses `http://127.0.0.1:8000/api` from `frontend/.env`.

## Security

- Do not commit `.env` files or production secrets.
- Change any demo/admin password before production.
- Use HTTPS for both frontend and backend.
- Use PostgreSQL and durable file storage in production.
